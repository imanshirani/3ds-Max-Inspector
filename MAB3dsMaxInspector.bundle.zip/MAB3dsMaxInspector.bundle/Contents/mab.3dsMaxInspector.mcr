macroScript MaxInspector category:"MYARTSBOX" tooltip:"MaxInspector"
(
    filein "mab.3dsMaxInspector.ms" 
)